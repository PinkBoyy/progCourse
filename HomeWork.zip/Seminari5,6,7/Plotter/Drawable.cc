#include "Drawable.hh"
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <unistd.h>

using namespace std;

int Drawable::fDrCount = 0;         //Starting number is 0

//Constructor
Drawable::Drawable(const char* name){ fName = name; fDrCount++; fDisplayError = false;}

//Destructor
Drawable::~Drawable(){
    string command = "rm ";
    command += fName;
    system(command.c_str());
}

//SetError
void Drawable::ShowError(bool a){
    fDisplayError = a;
}

//Draw function
void Drawable::Draw(const char* option){
    
    fDrCount--;   //decreasing the number of objects since they are already drawn
    
/*------------------YOU CAN ENABLE IT BY UNCOMMENTING------------------------------*/  
    /*  //<--uncomment here
    //display points
    cout << "\n";
    for(int i = 0; i < fXdata.size(); i++){
        cout << "x = " << fXdata[i] << " :  y = " << fYdata[i] << " :  ey = " << fEYdata[i] << endl;
    }
    
    cout << endl; */ //<--Uncomment here
/*--------------------------------------------------------------------*/    

    
/*--------------------------------------------------------------------*/    
    //insert data into file.txt
    ofstream mydata;
    mydata.open(fName);
    for(int i = 0; i < fXdata.size(); i++){
        mydata << fXdata[i] << "\t" << fYdata[i] << "\t" << fEYdata[i] << "\n";
    }
    
    mydata.close();
/*--------------------------------------------------------------------*/    
    

/*--------------------------------------------------------------------*/    
    //call kst program and display as ordered
   string command = "kst2 ";
   
   if(fDisplayError) command += option + fName + " -x 1 -e 3 -y 2&"; 
    else command += option + fName + " -x 1 -y 2&"; 
    
    system(command.c_str());
/*--------------------------------------------------------------------*/  

/*--------------------------------------------------------------------*/  
    //sleep if it is the last Draw!!
    if(fDrCount == 0){
        sleep(2);
    }
}

